package com.beatx.music

import android.Manifest
import android.app.DownloadManager
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.media.audiofx.Equalizer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import java.util.concurrent.Executor

data class Song(val id: Long, val title: String, val artist: String, val uri: Uri)

class MainActivity : ComponentActivity() {
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var mediaController by mutableStateOf<MediaController?>(null)
    private var equalizer: Equalizer? = null

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) loadSongs()
        else Toast.makeText(this, "Audio permission is needed to show your music.", Toast.LENGTH_LONG).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        connectController()
        requestAudioPermission()
        setContent {
            BeatxTheme {
                BeatxApp(
                    songsProvider = { loadSongsList() },
                    onPlay = { songs, index -> playSongs(songs, index) },
                    onDownload = { url -> downloadAudio(url) },
                    onEqualizer = { enabled -> setEqualizer(enabled) },
                    onBandChange = { band, level -> setBand(band, level) },
                    controller = mediaController
                )
            }
        }
    }

    private fun connectController() {
        val token = SessionToken(this, android.content.ComponentName(this, MusicService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync()
        controllerFuture?.addListener({
            try { mediaController = controllerFuture?.get() } catch (_: Exception) { }
        }, Executor { it.run() })
    }

    private fun requestAudioPermission() {
        val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
                         else Manifest.permission.READ_EXTERNAL_STORAGE
        if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
            permissionLauncher.launch(permission)
        }
    }

    private fun loadSongs() { /* UI reloads the library when permission is granted. */ }

    private fun loadSongsList(): List<Song> {
        val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
                         else Manifest.permission.READ_EXTERNAL_STORAGE
        if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) return emptyList()
        val list = mutableListOf<Song>()
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST
        )
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        contentResolver.query(collection, projection, selection, null, "${MediaStore.Audio.Media.TITLE} ASC")?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                val uri = ContentUris.withAppendedId(collection, id)
                list += Song(id, cursor.getString(titleCol) ?: "Unknown title",
                    cursor.getString(artistCol) ?: "Unknown artist", uri)
            }
        }
        return list
    }

    private fun playSongs(songs: List<Song>, index: Int) {
        val controller = mediaController ?: run {
            Toast.makeText(this, "Player is starting. Try again in a moment.", Toast.LENGTH_SHORT).show()
            return
        }
        val items = songs.map { song ->
            MediaItem.Builder().setUri(song.uri).setMediaMetadata(
                MediaMetadata.Builder().setTitle(song.title).setArtist(song.artist).build()
            ).build()
        }
        controller.setMediaItems(items, index, 0L)
        controller.prepare()
        controller.play()
        attachEqualizer(controller.audioSessionId)
    }

    private fun attachEqualizer(sessionId: Int) {
        try {
            equalizer?.release()
            if (sessionId > 0) equalizer = Equalizer(0, sessionId)
        } catch (_: Exception) { equalizer = null }
    }

    private fun setEqualizer(enabled: Boolean) {
        try {
            val eq = equalizer
            if (eq == null) Toast.makeText(this, "Play a song first to enable equalizer.", Toast.LENGTH_SHORT).show()
            else eq.enabled = enabled
        } catch (_: Exception) { }
    }

    private fun setBand(band: Int, level: Int) {
        try {
            val eq = equalizer ?: return
            if (band in 0 until eq.numberOfBands) eq.setBandLevel(band.toShort(), level.toShort())
        } catch (_: Exception) { }
    }

    private fun downloadAudio(url: String) {
        try {
            val uri = Uri.parse(url.trim())
            if (uri.scheme != "https" && uri.scheme != "http") {
                Toast.makeText(this, "Enter a valid http/https audio link.", Toast.LENGTH_LONG).show()
                return
            }
            val request = DownloadManager.Request(uri)
                .setTitle("VIBE X download")
                .setDescription("Downloading audio file")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_MUSIC, "VIBE_X_${System.currentTimeMillis()}.mp3")
                .setAllowedOverMetered(true)
            (getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(request)
            Toast.makeText(this, "Download started. Use links you have permission to download.", Toast.LENGTH_LONG).show()
        } catch (_: Exception) {
            Toast.makeText(this, "Could not start download. Check the link.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onDestroy() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        equalizer?.release()
        equalizer = null
        super.onDestroy()
    }
}

@Composable
fun BeatxTheme(content: @Composable () -> Unit) {
    val colors = darkColorScheme(
        primary = Color(0xFFB7F34A),
        secondary = Color(0xFF8B7CFF),
        background = Color(0xFF090B12),
        surface = Color(0xFF151925),
        onBackground = Color.White,
        onSurface = Color.White
    )
    MaterialTheme(colorScheme = colors, content = content)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BeatxApp(
    songsProvider: () -> List<Song>,
    onPlay: (List<Song>, Int) -> Unit,
    onDownload: (String) -> Unit,
    onEqualizer: (Boolean) -> Unit,
    onBandChange: (Int, Int) -> Unit,
    controller: MediaController?
) {
    var songs by remember { mutableStateOf(emptyList<Song>()) }
    var search by remember { mutableStateOf("") }
    var tab by remember { mutableStateOf(0) }
    var downloadUrl by remember { mutableStateOf("") }
    var eqEnabled by remember { mutableStateOf(false) }
    var showEq by remember { mutableStateOf(false) }
    var playlist by remember { mutableStateOf(listOf<Song>()) }
    var isPlaying by remember { mutableStateOf(false) }
    var currentTitle by remember { mutableStateOf("Choose a song") }

    LaunchedEffect(Unit) { songs = songsProvider() }
    LaunchedEffect(controller) {
        while (true) {
            controller?.let {
                isPlaying = it.isPlaying
                currentTitle = it.mediaMetadata.title?.toString() ?: "Choose a song"
            }
            kotlinx.coroutines.delay(500)
        }
    }

    val visibleSongs = songs.filter {
        it.title.contains(search, true) || it.artist.contains(search, true)
    }

    Scaffold(
        containerColor = Color(0xFF090B12),
        bottomBar = {
            NavigationBar(containerColor = Color(0xFF111622), contentColor = Color.White) {
                NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Icon(Icons.Default.MusicNote, null) }, label = { Text("Library") })
                NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Icon(Icons.Default.QueueMusic, null) }, label = { Text("Playlist") })
                NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Icon(Icons.Default.Download, null) }, label = { Text("Downloads") })
            }
        }
    ) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).background(
                Brush.verticalGradient(listOf(Color(0xFF191C32), Color(0xFF090B12)))
            ).padding(horizontal = 18.dp)
        ) {
            Spacer(Modifier.height(22.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("VIBE X", color = Color(0xFFB7F34A), fontSize = 29.sp, fontWeight = FontWeight.Black)
                    Text("YOUR SOUND. YOUR WORLD.", color = Color.LightGray, fontSize = 10.sp, letterSpacing = 2.sp)
                }
                Surface(shape = CircleShape, color = Color(0xFF292D43), modifier = Modifier.size(44.dp)) {
                    Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.GraphicEq, null, tint = Color(0xFFB7F34A)) }
                }
            }
            Spacer(Modifier.height(18.dp))
            if (tab == 0) {
                OutlinedTextField(
                    value = search, onValueChange = { search = it },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Search songs or artists") },
                    leadingIcon = { Icon(Icons.Default.Search, null) },
                    singleLine = true,
                    shape = RoundedCornerShape(18.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color(0xFFB7F34A),
                        unfocusedBorderColor = Color(0xFF34394B),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    )
                )
                Spacer(Modifier.height(16.dp))
                Text("YOUR MUSIC", color = Color.White, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                Text("${songs.size} tracks on this device", color = Color.LightGray, fontSize = 12.sp)
                Spacer(Modifier.height(10.dp))
                if (visibleSongs.isEmpty()) {
                    Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.LibraryMusic, null, tint = Color(0xFFB7F34A), modifier = Modifier.size(48.dp))
                            Spacer(Modifier.height(8.dp))
                            Text(if (songs.isEmpty()) "No music found yet" else "No matching songs", color = Color.White, fontWeight = FontWeight.SemiBold)
                            Text("Add audio files to your phone's Music folder", color = Color.LightGray, fontSize = 12.sp)
                        }
                    }
                } else {
                    LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 12.dp)) {
                        itemsIndexed(visibleSongs) { index, song ->
                            SongRow(song, onClick = {
                                val realIndex = songs.indexOf(song)
                                onPlay(songs, realIndex)
                                playlist = songs
                            }, onAdd = { playlist = (playlist + song).distinctBy { it.id } })
                        }
                    }
                }
            } else if (tab == 1) {
                Text("MY PLAYLIST", color = Color.White, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                Text("${playlist.size} saved in this session", color = Color.LightGray, fontSize = 12.sp)
                Spacer(Modifier.height(12.dp))
                if (playlist.isEmpty()) {
                    Text("Tap + on any song to add it here.", color = Color.LightGray)
                } else {
                    LazyColumn(Modifier.weight(1f)) {
                        itemsIndexed(playlist) { index, song ->
                            SongRow(song, onClick = { onPlay(playlist, index) }, onAdd = { })
                        }
                    }
                }
            } else {
                Text("DOWNLOAD AUDIO", color = Color.White, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                Text("Save audio from a direct link you are allowed to download.", color = Color.LightGray, fontSize = 12.sp)
                Spacer(Modifier.height(18.dp))
                OutlinedTextField(
                    value = downloadUrl, onValueChange = { downloadUrl = it },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("https://example.com/audio.mp3") },
                    label = { Text("Direct audio URL") },
                    singleLine = true
                )
                Spacer(Modifier.height(10.dp))
                Button(onClick = { onDownload(downloadUrl) }, enabled = downloadUrl.isNotBlank(),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB7F34A), contentColor = Color.Black)) {
                    Icon(Icons.Default.Download, null); Spacer(Modifier.width(6.dp)); Text("Download audio")
                }
                Spacer(Modifier.height(12.dp))
                Text("Downloaded files are saved in your Music folder. Refresh/reopen the app to see them in Library.", color = Color.LightGray, fontSize = 12.sp)
            }

            if (tab != 2) {
                Card(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF20263A)),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Column(Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(shape = RoundedCornerShape(12.dp), color = Color(0xFF343B56), modifier = Modifier.size(44.dp)) {
                                Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.Album, null, tint = Color(0xFFB7F34A)) }
                            }
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text("NOW PLAYING", color = Color(0xFFB7F34A), fontSize = 9.sp, letterSpacing = 1.5.sp)
                                Text(currentTitle, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            IconButton(onClick = { showEq = true }) { Icon(Icons.Default.Equalizer, null, tint = Color(0xFFB7F34A)) }
                            IconButton(onClick = {
                                controller?.let { if (it.isPlaying) it.pause() else it.play() }
                            }) { Icon(if (isPlaying) Icons.Default.PauseCircle else Icons.Default.PlayCircle, null, tint = Color(0xFFB7F34A), modifier = Modifier.size(34.dp)) }
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            IconButton(onClick = { controller?.seekToPreviousMediaItem() }) { Icon(Icons.Default.SkipPrevious, null, tint = Color.White) }
                            IconButton(onClick = { controller?.seekToNextMediaItem() }) { Icon(Icons.Default.SkipNext, null, tint = Color.White) }
                        }
                    }
                }
            }
        }
    }

    if (showEq) {
        AlertDialog(
            onDismissRequest = { showEq = false },
            title = { Text("VIBE X Equalizer") },
            text = {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Equalizer")
                        Spacer(Modifier.weight(1f))
                        Switch(checked = eqEnabled, onCheckedChange = {
                            eqEnabled = it; onEqualizer(it)
                        })
                    }
                    Text("Play a song first. Band sliders adjust your device equalizer.", fontSize = 12.sp, color = Color.Gray)
                    (0..4).forEach { band ->
                        var value by remember { mutableFloatStateOf(0f) }
                        Text("Band ${band + 1}: ${value.toInt()}")
                        Slider(value = value, onValueChange = {
                            value = it; onBandChange(band, (it * 900).toInt())
                        }, valueRange = -1f..1f)
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showEq = false }) { Text("Done") } }
        )
    }
}

@Composable
fun SongRow(song: Song, onClick: () -> Unit, onAdd: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable { onClick() }.padding(vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Surface(shape = RoundedCornerShape(12.dp), color = Color(0xFF282E43), modifier = Modifier.size(46.dp)) {
            Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.MusicNote, null, tint = Color(0xFFB7F34A)) }
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(song.title, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(song.artist, color = Color.LightGray, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        IconButton(onClick = onAdd) { Icon(Icons.Default.Add, null, tint = Color(0xFFB7F34A)) }
        IconButton(onClick = onClick) { Icon(Icons.Default.PlayArrow, null, tint = Color.White) }
    }
}
