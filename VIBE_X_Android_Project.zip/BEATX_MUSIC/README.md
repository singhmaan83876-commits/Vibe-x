# VIBE X — Android starter project

A dark, neon-accented Android music player starter app.

## Included
- Local music library using Android MediaStore
- Search by song title or artist
- Play, pause, next and previous
- Background playback using AndroidX Media3 `MediaSessionService`
- In-memory playlist for the current app session
- Direct audio-file downloads using Android DownloadManager
- Android system Equalizer controls (availability depends on the device)

## Build the APK
1. Install Android Studio (current stable version) and Android SDK 35.
2. Open this folder in Android Studio.
3. Let Gradle sync finish.
4. Connect an Android phone with USB debugging enabled, or use an emulator.
5. Press Run to install the app.
6. To create an APK: Build → Build Bundle(s) / APK(s) → Build APK(s).

## Notes
- This is a source project, not a prebuilt APK.
- On first launch, allow music/audio permission.
- Put audio files you own or are licensed to use in the phone's Music folder.
- Downloads accept direct HTTP/HTTPS audio links only. Only download tracks when you have permission.
- Playlist entries are kept in memory for the current app session; persistent playlist storage can be added next.
- Equalizer support varies by phone/audio output. Start playback before enabling it.
- Android Studio may prompt you to update Gradle/Android Gradle Plugin if your installed version differs.
